# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

amsterdam = Tournament.create(name:"Amsterdam")
barcelona = Tournament.create(name:"Barcelona")
bucharest = Tournament.create(name:"Bucharest")

alina = Player.create(name:"Alina")
marjon = Player.create(name:"Marjon")
jake = Player.create(name:"Jake")
flo = Player.create(name:"Flo")
