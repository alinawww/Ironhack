class AddBelongingToRegistration < ActiveRecord::Migration
  def change
  end

end
