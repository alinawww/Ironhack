class AddRegistrationsTable < ActiveRecord::Migration
  def change

  end
end
