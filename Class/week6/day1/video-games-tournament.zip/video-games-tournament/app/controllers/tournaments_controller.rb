class TournamentsController < ApplicationController
  def index
    @tournaments = Tournament.all
    # render(:index)
  end

  def destroy
    @tournament = Tournament.find_by(id: params[:id])
    @tournament.destroy
    render 'index'
  end

  def create
    tournament = Tournament.create(tournament_params)
    # byebug
    render json: tournament, status: 201
  end

  def show
    @tournament = Tournament.find_by(id: params[:id])
    render json: tournament
  end

  private

  def tournament_params
    params.require(:tournament)
      .permit(:name)
  end

end
