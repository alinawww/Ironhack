class Registration < ActiveRecord::Base
end
