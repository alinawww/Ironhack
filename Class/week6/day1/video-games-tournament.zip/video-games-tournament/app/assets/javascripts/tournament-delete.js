function deleteTournament (event) {
  event.preventDefault()
  var tournamentId = $('[data-hook="tourney-delete"]').val()
  var request = $.ajax({
        url: '/api/tournaments/'+tournamentId,
        type: 'DELETE',
        data: {id: tournamentId},
      });
  $('[value = '+tournamentId+']').parent().remove()
  }
