class SandwichIngredient < ActiveRecord::Migration
  def change
  end
end
