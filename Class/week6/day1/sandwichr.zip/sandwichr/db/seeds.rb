# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

tomato = Ingredient.create(name:'tomato', calories: 30)
cheese = Ingredient.create(name:'cheese', calories: 100)

blt = Sandwich.create(name:"BLT", bread_type: "white")
club = Sandwich.create(name:"Club", bread_type: "black")


blt.ingredients.push(tomato)
# club.ingredients.create(ingredient: tomato)
