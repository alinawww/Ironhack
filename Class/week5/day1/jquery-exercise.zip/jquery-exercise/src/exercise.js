var phrases = [
  "Frankly, my dear, I don't give a damn!",
  "Hello world!",
  "Life is long.",
  "What is love, baby don't herd me."
]

var jsPhrases = $(phrases)

$('#add-quote-form').on("submit", function(e){
  e.preventDefault()
  var newQuote = $('[name="add-quote"]').val()
  phrases.push(newQuote);
  location.reload();
})


var randQuote = jsPhrases[Math.floor(Math.random()* phrases.length)]

$('.random-quote').text(randQuote)

$('[name=refresh]').on("click", function(){
  location.reload();
});
