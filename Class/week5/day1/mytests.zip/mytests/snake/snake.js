
$(document).ready(function() {
            var max = 100;
            for (var i = 0; i < max; i++) {
                var cell = $('<div>');
                cell.addClass('cell blue')
                $('.container').append(cell);
                var cells = $('.cell');
                var row = cells.slice(10)
            }
            });
            setInterval(function() {
                var cells = $('.cell');
                cells.each(function(index, element) {
                    var head = $('.cell:first');
                    head.removeClass('blue');
                    head.addClass('red');
                }, 300);
            });

// $(document).on('keypress', function(e){
//   console.log('you prssed a key');
//   console.log(e.keyCode);
//   cell.toggleClass('red')
// });

// setInterval(function(){
//   var cells = $('.cell');
//   cells.each(function(index, element){
//     var even = $(cells[index*2])
//     even.toggleClass('red');
//     $(element).toggleClass('blue');
//   })
// }, 1000);
